<?php
session_start();
    define('ROOT_URL', 'http://localhost/php/boltaindia/');
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_NAME', 'boltaindia');
?>